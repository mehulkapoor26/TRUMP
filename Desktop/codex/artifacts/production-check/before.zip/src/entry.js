import lodash from 'lodash';
export function handler() {
  return lodash({});
}
